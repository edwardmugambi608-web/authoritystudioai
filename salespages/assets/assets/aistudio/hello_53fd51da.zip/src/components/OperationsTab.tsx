import React, { useState } from 'react';
import { 
  Radio, 
  Globe, 
  ShieldCheck, 
  Lock, 
  Check, 
  Sparkles, 
  DollarSign, 
  CreditCard,
  Send,
  Webhook,
  Zap,
  CheckCircle2,
  Key,
  Copy
} from 'lucide-react';
import { BusinessWorkspace, ProductTier } from '../types/authority';
import { store, PRODUCT_CONFIGS } from '../services/store';
import confetti from 'canvas-confetti';

interface OperationsTabProps {
  workspace: BusinessWorkspace;
  currentPlan: ProductTier;
}

export const OperationsTab: React.FC<OperationsTabProps> = ({ workspace, currentPlan }) => {
  const [customDomainInput, setCustomDomainInput] = useState(workspace.customDomain || '');
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishMessage, setPublishMessage] = useState<string | null>(null);

  // Stripe & PayPal Gateway Simulation State
  const [stripeConnected, setStripeConnected] = useState(true);
  const [licensePriceInput, setLicensePriceInput] = useState(19);
  const [simulatedCheckoutSuccess, setSimulatedCheckoutSuccess] = useState<string | null>(null);
  const [generatedLicenseKey, setGeneratedLicenseKey] = useState<string | null>(null);

  // CRM Webhook Auto-Sync State
  const [selectedCrm, setSelectedCrm] = useState<'convertkit' | 'activecampaign' | 'mailchimp' | 'zapier'>('convertkit');
  const [webhookUrl, setWebhookUrl] = useState('https://api.convertkit.com/v3/subscribers?api_secret=ck_live_984f2');
  const [webhookStatus, setWebhookStatus] = useState<string | null>(null);

  // Geo-Targeting Currency Switcher State
  const [activeCurrency, setActiveCurrency] = useState<'USD' | 'EUR' | 'GBP' | 'CAD' | 'AUD'>('USD');
  const currencySymbols = { USD: '$', EUR: '€', GBP: '£', CAD: 'CA$', AUD: 'AU$' };
  const currencyRates = { USD: 1.0, EUR: 0.92, GBP: 0.79, CAD: 1.36, AUD: 1.52 };

  const entitlement = PRODUCT_CONFIGS[currentPlan] || PRODUCT_CONFIGS.CORE;

  const handlePublish = () => {
    setIsPublishing(true);
    setTimeout(() => {
      const res = store.publishWorkspace(workspace.id, customDomainInput.trim() || undefined);
      setIsPublishing(false);
      if (res.success) {
        confetti({ particleCount: 75, spread: 65, origin: { y: 0.6 } });
        setPublishMessage(`Successfully deployed to ${workspace.publishedUrl || 'live cloud edge'}`);
        setTimeout(() => setPublishMessage(null), 3500);
      }
    }, 900);
  };

  const handleUnpublish = () => {
    store.unpublishWorkspace(workspace.id);
    setPublishMessage('Property unpublished and returned to private staging.');
    setTimeout(() => setPublishMessage(null), 3500);
  };

  const handleSimulatePayment = () => {
    const key = `AUTH-ENG-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
    setGeneratedLicenseKey(key);
    store.addOrder(workspace.id, 'customer@example.com', 'Decision Engine Pro Lifetime Pass', licensePriceInput, false);
    confetti({ particleCount: 70, spread: 60 });
    setSimulatedCheckoutSuccess(`Received payment of ${currencySymbols[activeCurrency]}${Math.round(licensePriceInput * currencyRates[activeCurrency])}! Automated license key provisioned.`);
    setTimeout(() => setSimulatedCheckoutSuccess(null), 4000);
  };

  const handleTestWebhook = () => {
    setWebhookStatus(`Webhook test payload sent to ${selectedCrm.toUpperCase()}! Response HTTP 200 OK.`);
    confetti({ particleCount: 35, spread: 40 });
    setTimeout(() => setWebhookStatus(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2.5 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/20">
              <Radio className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                  Business Builder Edition (OTO 1)
                </span>
                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  Full Automation Active
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1 font-display">
                Automated Operations &amp; Payment Gateway Engine
              </h1>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Turn your authority property into an automated revenue engine with direct Stripe/PayPal checkouts, automated customer license key delivery, custom domains, and CRM webhooks.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {workspace.isPublished ? (
            <button 
              onClick={handleUnpublish}
              className="px-4 py-2 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors border border-rose-200"
            >
              Unpublish Site
            </button>
          ) : (
            <button 
              onClick={handlePublish}
              disabled={isPublishing}
              className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{isPublishing ? 'Deploying to Cloud...' : 'Publish Live to Web'}</span>
            </button>
          )}
        </div>
      </div>

      {publishMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-xs flex items-center gap-2 font-medium">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{publishMessage}</span>
        </div>
      )}

      {/* Grid: 4 Core Operational Modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Module 1: Direct Stripe & PayPal Payment Gateway */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              <span>Stripe &amp; PayPal Direct Gateway</span>
            </h3>
            <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Live Checkout Ready
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Sell $19 Decision Engine passes or downloadable bundles. Customers receive instant verification and automated browser unlock tokens.
          </p>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-700">Decision Engine Paywall Price:</span>
              <div className="flex items-center gap-1 font-mono font-bold text-slate-900">
                <span>{currencySymbols[activeCurrency]}</span>
                <input 
                  type="number"
                  value={licensePriceInput}
                  onChange={(e) => setLicensePriceInput(Number(e.target.value))}
                  className="w-16 px-2 py-1 text-xs border border-slate-300 rounded bg-white text-right font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleSimulatePayment}
              className="w-full py-2.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 font-display"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Simulate Customer Purchase ({currencySymbols[activeCurrency]}{Math.round(licensePriceInput * currencyRates[activeCurrency])})</span>
            </button>
          </div>

          {generatedLicenseKey && (
            <div className="p-3 bg-slate-950 text-emerald-400 rounded-xl font-mono text-[11px] flex items-center justify-between">
              <span className="truncate">Key: {generatedLicenseKey}</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(generatedLicenseKey);
                  confetti({ particleCount: 20, spread: 30 });
                }}
                className="text-xs text-white hover:text-emerald-300 ml-2"
              >
                Copy
              </button>
            </div>
          )}

          {simulatedCheckoutSuccess && (
            <div className="text-xs text-emerald-700 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
              {simulatedCheckoutSuccess}
            </div>
          )}
        </div>

        {/* Module 2: Email CRM Webhook Auto-Sync */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Webhook className="w-4 h-4 text-purple-600" />
              <span>Email CRM Webhook Auto-Sync</span>
            </h3>
            <span className="text-[10px] font-mono font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
              Automated Push
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Every captured lead from your decision engines or playbook forms is instantly forwarded to your autoresponder list via automated webhooks.
          </p>

          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-1.5">
              {(['convertkit', 'activecampaign', 'mailchimp', 'zapier'] as const).map(crm => (
                <button
                  key={crm}
                  type="button"
                  onClick={() => setSelectedCrm(crm)}
                  className={`py-1.5 text-[11px] font-bold rounded-lg capitalize border transition-all ${
                    selectedCrm === crm 
                      ? 'bg-slate-900 text-white border-slate-900' 
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {crm}
                </button>
              ))}
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Target Endpoint Webhook URL</label>
              <input 
                type="text"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 bg-white"
              />
            </div>

            <button
              onClick={handleTestWebhook}
              className="w-full py-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5 text-purple-600" />
              <span>Send Test Lead Webhook Payload</span>
            </button>

            {webhookStatus && (
              <div className="text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                {webhookStatus}
              </div>
            )}
          </div>
        </div>

        {/* Module 3: Dynamic Geo-Targeting & Local Currency Switcher */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span>Geo-Targeting &amp; Currency Switcher</span>
            </h3>
            <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              IP-Based Detection
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            Automatically adapts all decision engine outputs, regional cost indexes, and pricing badges to the visitor's local country and currency.
          </p>

          <div className="space-y-3">
            <div className="flex items-center gap-1.5">
              {(['USD', 'EUR', 'GBP', 'CAD', 'AUD'] as const).map(curr => (
                <button
                  key={curr}
                  type="button"
                  onClick={() => setActiveCurrency(curr)}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all ${
                    activeCurrency === curr
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {currencySymbols[curr]} {curr}
                </button>
              ))}
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
              <div className="text-slate-600">Simulated Visitor View:</div>
              <div className="font-bold text-slate-900 text-sm">
                Sample Output: {currencySymbols[activeCurrency]}{(54000 * currencyRates[activeCurrency]).toLocaleString()} {activeCurrency}
              </div>
              <div className="text-[10px] text-slate-400 font-mono">Exchange Multiplier: {currencyRates[activeCurrency]}x</div>
            </div>
          </div>
        </div>

        {/* Module 4: Custom Domain Command & Edge SSL */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-600" />
              <span>Custom Domain &amp; Edge SSL Routing</span>
            </h3>
            <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              2048-Bit TLS
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Apex or Sub-Domain Name
              </label>
              <input 
                type="text"
                placeholder="e.g. www.apexremodeling.com"
                value={customDomainInput}
                onChange={(e) => setCustomDomainInput(e.target.value)}
                className="w-full px-3.5 py-2 text-xs font-mono rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs">
              <div className="font-bold text-slate-800">Automated Edge DNS Target:</div>
              <div className="font-mono text-[11px] bg-white p-2 rounded border border-slate-200 text-slate-700 select-all">
                CNAME &rarr; edge.authoritystudio.app
              </div>
            </div>

            <button 
              onClick={handlePublish}
              className="w-full py-2.5 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl shadow-2xs transition-colors"
            >
              Verify DNS &amp; Deploy Custom Domain
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
