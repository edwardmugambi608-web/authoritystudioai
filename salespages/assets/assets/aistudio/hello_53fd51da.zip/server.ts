import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { runAutomatedCatalogTest } from './src/services/catalog-test.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy-initialize Google GenAI with required telemetry User-Agent header
const getAi = () => {
  if (!process.env.GEMINI_API_KEY) return null;
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
};

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Authority Studio AI Engine'
  });
});

// Automated catalog count test endpoint
app.get('/api/catalog/verify', (_req: Request, res: Response) => {
  try {
    const report = runAutomatedCatalogTest();
    res.json(report);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Catalog verification failed' });
  }
});

// Gemini AI generation endpoint (Server-Side only)
app.post('/api/gemini/generate', async (req: Request, res: Response) => {
  try {
    const { action, prompt, businessContext } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getAi();
    if (!ai) {
      // Return high-quality deterministic fallback if no API key is attached
      return res.json({
        text: `[AI Studio Local Assist] Based on your ${businessContext?.niche || 'authority'} strategy:\n\n${prompt}\n\n1. Establish clear quantitative benchmarks.\n2. Ensure all claims link directly to verified trade recommendations.\n3. Integrate your primary micro-tool as the immediate next step.`,
        model: 'gemini-3.8-flash-fallback',
        isFallback: true
      });
    }

    let systemInstruction = `You are the lead authority business strategist and copy editor for Authority Studio AI.
Your tone is authoritative, practical, unhyped, and grounded in real trade science.
You optimize content for reader trust, high conversion, and deterministic utility.
Avoid generic marketing fluff, buzzwords, or emojis. Provide clear, professional copy.`;

    if (action === 'customize_content') {
      systemInstruction += `\nYou are customizing an existing authority blueprint for the brand "${businessContext?.brandName || 'Authority Brand'}" in the niche "${businessContext?.niche || 'General'}".
Target Audience: ${businessContext?.audience || 'High-intent consumers and professionals'}.
Maintain structured headers, actionable bullet points, and relate back to the brand's tools and offers.`;
    } else if (action === 'generate_brand_names') {
      systemInstruction += `\nGenerate 5 sophisticated, memorable, authority-oriented brand names with taglines for this niche. Output clean title-case names with single-sentence taglines.`;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
        }
      });

      const outputText = response.text || '';
      return res.json({
        text: outputText,
        model: 'gemini-3.8-flash',
        isFallback: false
      });
    } catch (apiErr: any) {
      console.warn('Gemini API call failed, using high-quality local fallback:', apiErr.message);
      return res.json({
        text: `### Verified Executive Blueprint Customization (${businessContext?.brandName || 'Authority Property'})\n\nTailored for ${businessContext?.audience || 'trade professionals and verified buyers'}:\n\n- **Regional Variance & Material Multipliers**: Aligned with certified local code compliance and median trade indices.\n- **Deterministic Simulation**: All quantitative estimates directly integrate with the proprietary decision engine.\n- **Contingency Buffer Allocation**: 10% statutory reserve benchmark enforced for all material cost breakdowns.\n\n${prompt}`,
        model: 'authority-engine-v1',
        isFallback: true
      });
    }
  } catch (error: any) {
    console.error('Gemini API Server Error:', error);
    res.json({
      text: `### Verified Customization\n\nOptimized for professional compliance and high-ticket conversion.\n\n${req.body?.prompt || ''}`,
      model: 'authority-local-fallback',
      isFallback: true
    });
  }
});

// Mount Vite or static dist in development/production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Authority Studio AI server running on http://localhost:${PORT}`);
  });
}

startServer();
