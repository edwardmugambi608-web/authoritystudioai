import React from 'react';
import { 
  LayoutDashboard, 
  Globe, 
  Wrench, 
  FileText, 
  Mail, 
  DollarSign, 
  Download, 
  Radio, 
  Layers, 
  Building2, 
  X, 
  Compass, 
  LogOut, 
  Zap, 
  Repeat, 
  Calendar, 
  Share2,
  ShieldAlert,
  Users,
  Award,
  MapPin
} from 'lucide-react';
import { ProductTier } from '../types/authority';
import { PRODUCT_CONFIGS, store, isAdminUser } from '../services/store';

export type TabKey = 
  | 'dashboard' 
  | 'niches'
  | 'launch_plan'
  | 'website' 
  | 'tools' 
  | 'content' 
  | 'lead_magnet' 
  | 'monetization' 
  | 'exports' 
  | 'operations' 
  | 'portfolio' 
  | 'commercial' 
  | 'cloner'
  | 'repurposing'
  | 'client_portals'
  | 'license'
  | 'local_event'
  | 'catalog_audit'
  | 'admin';

interface SidebarProps {
  activeTab: TabKey;
  onSelectTab: (tab: TabKey) => void;
  currentPlan: ProductTier;
  activeSuite: ProductTier;
  onSelectSuite: (suite: ProductTier) => void;
  onUpgradePrompt: (featureName: string, requiredTier: ProductTier) => void;
  onOpenVaultModal?: () => void;
  isOpen?: boolean;
  onClose?: () => void;
  onOpenCreateModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentPlan,
  activeSuite,
  onSelectSuite,
  onUpgradePrompt,
  onOpenVaultModal,
  isOpen = false,
  onClose,
  onOpenCreateModal
}) => {
  const currentUser = store.getCurrentUser();
  const nextUpgradeTier = store.getNextUpgradeTier();
  const isAdmin = isAdminUser(currentUser?.username);

  interface NavItemDef {
    id: TabKey;
    label: string;
    icon: React.ElementType;
    badge?: string;
    requiresTier?: ProductTier;
    isLocked?: boolean;
  }

  // Suite title definitions (clean, professional in-app titles without "Plan" or "OTO")
  const suiteMeta: Record<ProductTier, { name: string; tagline: string }> = {
    CORE: { name: 'Authority Studio AI', tagline: 'Turnkey Niche Property Builder' },
    EXTENDED: { name: 'Business Builder', tagline: 'Live Turnkey Operations' },
    PRO: { name: 'Expansion Studio', tagline: 'Portfolio Scaling & Traffic Repurposing' },
    ULTIMATE: { name: 'Commercial Empire', tagline: 'Commercial Agency Licensing' },
    CLOUD: { name: 'Authority Cloud', tagline: 'Managed Cloud Infrastructure' },
    LOCAL: { name: 'Local Authority Studio', tagline: 'Local Business Marketing' },
    EVENT: { name: 'Local Event Studio', tagline: 'Event Funnels & Directories' },
    FE: { name: 'Authority Studio AI', tagline: 'Turnkey Niche Property Builder' },
    OTO_1: { name: 'Business Builder', tagline: 'Live Turnkey Operations' },
    OTO_2: { name: 'Expansion Studio', tagline: 'Portfolio Scaling & Traffic Repurposing' },
    OTO_3: { name: 'Commercial Empire', tagline: 'Commercial Agency Licensing' }
  };

  const currentMeta = suiteMeta[activeSuite] || suiteMeta.CORE;

  const suiteOptions: { id: ProductTier; label: string; icon: React.ElementType }[] = [
    { id: 'CORE', label: 'Authority Studio', icon: Zap },
    { id: 'EXTENDED', label: 'Business Builder', icon: Radio },
    { id: 'PRO', label: 'Expansion Studio', icon: Layers },
    { id: 'ULTIMATE', label: 'Commercial Empire', icon: Building2 }
  ];

  // Zero-Confusion Hybrid Navigation Labels (Power Word + Concrete Literal Noun)
  let primaryNavItems: NavItemDef[] = [];

  if (activeSuite === 'CORE') {
    primaryNavItems = [
      { id: 'dashboard', label: 'Turnkey Business Overview', icon: LayoutDashboard },
      { id: 'niches', label: 'Profitable Niche Selector', icon: Compass },
      { id: 'website', label: 'Turnkey Website (11 Pages)', icon: Globe },
      { id: 'tools', label: 'Interactive Micro-Tools', icon: Wrench },
      { id: 'content', label: 'Authority Articles & Guides', icon: FileText },
      { id: 'lead_magnet', label: 'Lead Magnet & Automated Email Funnel', icon: Mail },
      { id: 'exports', label: 'Business-in-a-Box ZIP Exporter', icon: Download }
    ];
  } else if (activeSuite === 'EXTENDED') {
    primaryNavItems = [
      { id: 'operations', label: 'Live Custom Domains & SSL Command', icon: Radio },
      { id: 'website', label: 'Instant Web Publishing Engine', icon: Globe },
      { id: 'monetization', label: 'Monetization & Affiliate Hub', icon: DollarSign },
      { id: 'launch_plan', label: '30-Day Rapid Launch Roadmap', icon: Calendar },
      { id: 'tools', label: 'Paid Tool Paywall ($19 Access)', icon: Wrench },
      { id: 'dashboard', label: 'Return to Foundation Overview', icon: LayoutDashboard }
    ];
  } else if (activeSuite === 'PRO') {
    primaryNavItems = [
      { id: 'portfolio', label: '10-Business Portfolio Dashboard', icon: Layers },
      { id: 'cloner', label: '1-Click Turnkey Business Cloner', icon: Repeat },
      { id: 'repurposing', label: '1-into-7 Traffic Repurposing (PDF, Social & Video)', icon: Share2 },
      { id: 'exports', label: 'Multi-Business Bulk Exporter', icon: Download },
      { id: 'dashboard', label: 'Return to Foundation Overview', icon: LayoutDashboard }
    ];
  } else {
    // ULTIMATE
    primaryNavItems = [
      { id: 'commercial', label: 'Commercial Agency Control Center', icon: Building2 },
      { id: 'client_portals', label: 'Client Workspaces & Review Portals', icon: Users },
      { id: 'niches', label: '24-Niche Master Empire Vault', icon: Compass },
      { id: 'license', label: 'Commercial Reseller License Certificate', icon: Award },
      { id: 'local_event', label: 'High-Ticket Local & Event Marketing Kits', icon: MapPin },
      { id: 'dashboard', label: 'Return to Foundation Overview', icon: LayoutDashboard }
    ];
  }

  // Exclusive Admin Navigation
  if (isAdmin) {
    primaryNavItems.push({
      id: 'admin',
      label: 'WarriorPlus & Admin Hub',
      icon: ShieldAlert,
      badge: 'Admin'
    });
  }

  const handleItemClick = (item: NavItemDef, isMobile = false) => {
    if (item.isLocked && item.requiresTier) {
      onUpgradePrompt(item.label, item.requiresTier);
    } else {
      onSelectTab(item.id);
      if (isMobile && onClose) onClose();
    }
  };

  const renderNavBody = (isMobile: boolean) => (
    <>
      <div className="space-y-4">
        {/* Top Header of Sidebar: Blue edition badge only */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
          <span className="inline-flex items-center px-2.5 py-1 text-[10px] font-mono font-bold tracking-wider uppercase bg-blue-50 text-blue-700 border border-blue-200/80 rounded-md shadow-xs">
            {currentMeta.name.replace('Authority Studio AI ', '')} Edition
          </span>

          {isMobile && (
            <button 
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors shrink-0"
              aria-label="Close menu"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Switcher: ONLY displayed if user owns 2 or more unlocked suites */}
        {(() => {
          const unlockedSuites = suiteOptions.filter(suite => store.hasAccessToTier(suite.id));
          if (unlockedSuites.length <= 1) return null;

          return (
            <div className="space-y-1">
              <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                Switch Active Suite
              </span>
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200/80">
                {unlockedSuites.map(suite => {
                  const isActive = activeSuite === suite.id;
                  const Icon = suite.icon;

                  return (
                    <button
                      key={suite.id}
                      onClick={() => {
                        onSelectSuite(suite.id);
                        if (suite.id === 'CORE') onSelectTab('dashboard');
                        else if (suite.id === 'EXTENDED') onSelectTab('operations');
                        else if (suite.id === 'PRO') onSelectTab('portfolio');
                        else if (suite.id === 'ULTIMATE') onSelectTab('commercial');
                        if (isMobile && onClose) onClose();
                      }}
                      className={`flex items-center justify-center gap-1.5 p-1.5 rounded-lg text-[11px] font-bold transition-all ${
                        isActive
                          ? 'bg-white text-blue-600 shadow-xs'
                          : 'text-slate-700 hover:bg-slate-200/70'
                      }`}
                    >
                      <Icon className={`w-3 h-3 ${isActive ? 'text-blue-600' : 'text-slate-500'}`} />
                      <span className="truncate">{suite.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })()}

        {/* Navigation Items (Never collapses on desktop click!) */}
        <nav className="space-y-1">
          <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider block px-1 mb-1">
            Navigation
          </span>
          {primaryNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const isLocked = item.isLocked;
            const isItemAdmin = item.id === 'admin';

            return (
              <button
                key={item.id}
                onClick={() => handleItemClick(item, isMobile)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-xl transition-all text-left ${
                  isActive
                    ? isItemAdmin 
                      ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-xs'
                      : 'bg-gradient-to-r from-slate-900 to-slate-950 text-white shadow-xs border border-slate-800'
                    : isLocked
                    ? 'text-slate-400 hover:bg-slate-50'
                    : isItemAdmin
                    ? 'text-amber-700 hover:bg-amber-50 font-bold border border-amber-200/60'
                    : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : isItemAdmin ? 'text-amber-600' : isLocked ? 'text-slate-400' : 'text-slate-500'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono shrink-0 ml-1 ${
                    isActive 
                      ? 'bg-white/20 text-white font-bold' 
                      : isItemAdmin
                      ? 'bg-amber-100 text-amber-800 font-bold'
                      : 'bg-slate-200/70 text-slate-600'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Dedicated Upgrade Item (If higher tier available) */}
        {nextUpgradeTier && (
          <div className="pt-1">
            <button
              onClick={() => {
                onUpgradePrompt(PRODUCT_CONFIGS[nextUpgradeTier].name, nextUpgradeTier);
                if (isMobile && onClose) onClose();
              }}
              className="w-full flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-xs shadow-md shadow-blue-500/20 hover:from-blue-500 hover:to-indigo-500 transition-all"
            >
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-300" />
                <span>Upgrade Edition</span>
              </div>
              <span className="text-[10px] font-mono bg-white/20 px-1.5 py-0.5 rounded">
                {PRODUCT_CONFIGS[nextUpgradeTier].price}
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Bottom of Sidebar: Clean User Identity & Sign Out */}
      <div className="pt-3 border-t border-slate-100 text-xs space-y-1.5 mt-4">
        <div className="flex items-center justify-between px-1 py-1 text-slate-700">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 shadow-xs">
              {(currentUser?.username || 'F').charAt(0).toUpperCase()}
            </div>
            <div className="truncate">
              <div className="text-[11px] font-bold text-slate-900 truncate">
                {currentUser?.username || 'Founder'}
              </div>
              {isAdmin && (
                <span className="text-[8px] font-mono font-bold text-amber-600 uppercase">
                  Admin Verified
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            if (isMobile && onClose) onClose();
            store.logout();
          }}
          className="w-full flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors text-left"
        >
          <LogOut className="w-3.5 h-3.5 text-rose-500" />
          <span>Sign Out</span>
        </button>
      </div>
    </>
  );

  return (
    <>
      {/* Desktop Docked Sidebar: Always visible below top nav, never collapses on click */}
      <aside className="hidden lg:flex flex-col justify-between w-72 shrink-0 border-r border-slate-200 bg-white sticky top-16 h-[calc(100vh-4rem)] p-4 overflow-y-auto z-30">
        {renderNavBody(false)}
      </aside>

      {/* Mobile Slide-In Sidebar: Positioned strictly below the top nav bar (top-16) */}
      {isOpen && (
        <div className="lg:hidden fixed top-16 inset-x-0 bottom-0 z-50 flex animate-in fade-in duration-300">
          {/* Backdrop below top-16 */}
          <div 
            className="fixed top-16 inset-x-0 bottom-0 bg-slate-950/50 backdrop-blur-xs transition-opacity duration-300"
            onClick={onClose}
            aria-label="Close navigation"
          />

          {/* Drawer below top-16 */}
          <aside className="relative w-76 max-w-[85vw] bg-white h-full shadow-2xl p-4 overflow-y-auto z-10 animate-in slide-in-from-left duration-300 ease-out flex flex-col justify-between border-r border-slate-200">
            {renderNavBody(true)}
          </aside>
        </div>
      )}
    </>
  );
};
