import React, { useState } from 'react';
import { 
  Sparkles, 
  Layers, 
  FileText, 
  Share2, 
  Video, 
  Mail, 
  Copy, 
  Check, 
  Download, 
  CheckCheck,
  Zap,
  Lock,
  ArrowRight
} from 'lucide-react';
import { BusinessWorkspace, ContentAsset, ProductTier } from '../types/authority';
import { store, PRODUCT_CONFIGS } from '../services/store';

interface RepurposingModalProps {
  isOpen: boolean;
  onClose: () => void;
  workspace: BusinessWorkspace;
  asset: ContentAsset;
  onOpenUpgradeWall: (tier: ProductTier, featureName: string) => void;
}

export const RepurposingModal: React.FC<RepurposingModalProps> = ({
  isOpen,
  onClose,
  workspace,
  asset,
  onOpenUpgradeWall
}) => {
  const currentPlan = store.getPlan();
  const isProActive = store.hasAccessToTier('PRO');
  const [activeFormat, setActiveFormat] = useState<'pdf' | 'social' | 'carousel' | 'video' | 'newsletter' | 'pinterest'>('pdf');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  if (!isProActive) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
        <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="text-[10px] font-mono uppercase font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
              Feature Locked
            </span>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-sm font-bold">✕</button>
          </div>
          <div className="text-center space-y-3 py-2">
            <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 mx-auto flex items-center justify-center">
              <Layers className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              Expansion Studio Required
            </h3>
            <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
              The 1-into-7 Traffic Repurposing Engine (Article &rarr; PDF Guide, Social Posts, Carousel, Video Script, Newsletter, and Pinterest pins) requires <strong>Expansion Studio ($67)</strong>.
            </p>
          </div>
          <div className="pt-2 flex items-center justify-end gap-2">
            <button onClick={onClose} className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg">
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenUpgradeWall('PRO', '1-into-7 Traffic Repurposing Engine');
              }}
              className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5"
            >
              <span>Unlock Expansion Studio ($67)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  // Generate 7 distinct formats deterministically from the current asset
  const brand = workspace.brandProfile.name;
  const persona = workspace.audienceProfile.targetPersona;

  const pdfGuideText = `# ${asset.title}\n*Official Comprehensive Implementation Blueprint*\nPublished by ${brand} for ${persona}\n\n## Executive Summary\n${asset.excerpt}\n\n## Strategic Framework\n${asset.body}\n\n---\n**Action Checklist:**\n1. Audit current specifications against target parameters.\n2. Leverage the companion tool: ${asset.relatedToolId || 'Interactive Calculator'}.\n3. Download the full resource kit at ${workspace.publishedUrl || 'https://authoritystudio.app'}.\n\n© ${new Date().getFullYear()} ${brand}. All Rights Reserved.`;

  const socialPosts = [
    `1/5: Most people get "${asset.targetKeyword}" completely backwards. Here is the framework that actually works for ${persona} 👇`,
    `2/5: The core mistake? Trying to solve it without understanding: "${asset.excerpt.substring(0, 120)}..."`,
    `3/5: Key Rule: Look at the direct tradeoff between immediate output and compounding results. Real authority sites win by standardizing the workflow.`,
    `4/5: We built a dedicated micro-tool inside ${brand} that computes these exact thresholds in under 10 seconds.`,
    `5/5: Read our full in-depth review & grab the free blueprint: ${asset.title} at ${workspace.brandProfile.name}!`
  ];

  const carouselSlides = [
    { slide: 1, title: asset.title, sub: `A 60-second breakdown by ${brand}` },
    { slide: 2, title: 'The Common Pitfall', sub: asset.excerpt },
    { slide: 3, title: 'The 3 Non-Negotiable Rules', sub: 'Precision specs, verified benchmarks, and continuous operational review.' },
    { slide: 4, title: 'Pro Recommendation', sub: `Never deploy without checking the companion calculator tool.` },
    { slide: 5, title: 'Get the Free Checklist', sub: `Save this post and visit ${brand} for the full step-by-step breakdown.` }
  ];

  const videoScript = `[0:00 - Hook]: Stop doing ${asset.targetKeyword} the old way. If you're a ${persona}, this one shift saves hours.\n[0:15 - Problem]: ${asset.excerpt}\n[0:35 - Solution]: Here's the 3-step blueprint we use at ${brand}: First, audit your baseline numbers. Second, calculate your variance using our free tool. Third, automate the workflow.\n[0:50 - Call to Action]: Tap the link in bio to read our complete ${asset.title} and download the free guide!`;

  const newsletterBroadcast = `Subject: The real truth about ${asset.targetKeyword}\nPreview: Why standard advice fails for ${persona}\n\nHi {{first_name}},\n\nOver the past month, we've reviewed dozens of approaches to ${asset.targetKeyword}.\n\nHere's what our data shows:\n\n${asset.excerpt}\n\nIn our newest benchmark breakdown: "${asset.title}", we walk through the exact mathematical models and real-world results.\n\n👉 Read the complete breakdown here: [Link]\n\nP.S. Don't forget to run your numbers through our companion interactive tool!\n\nBest,\n${brand} Team`;

  const pinterestText = `Pin Title: The Ultimate ${asset.targetKeyword} Blueprint for ${persona}\nPin Description: Learn how to execute ${asset.targetKeyword} with precision. Get the step-by-step framework, comparison data, and companion micro-tools at ${brand}.\nHashtags: #${asset.targetKeyword.replace(/[^a-zA-Z0-9]/g, '')} #${brand.replace(/[^a-zA-Z0-9]/g, '')} #AuthorityGuide`;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <div className="text-[10px] font-mono text-blue-600 uppercase font-bold tracking-wider">
                Authority Studio AI Pro (OTO 2)
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                1-into-7 Traffic Repurposing Studio
              </h2>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-lg font-bold px-2 py-1">✕</button>
        </div>

        {/* Source Asset Indicator */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 flex items-center justify-between">
          <span className="truncate"><strong>Source Article:</strong> {asset.title}</span>
          <span className="text-[10px] font-mono text-slate-500 shrink-0 uppercase">{asset.category}</span>
        </div>

        {/* Format Selector Pills */}
        <div className="flex flex-wrap gap-1.5 border-b border-slate-100 pb-3 text-xs">
          <button
            onClick={() => setActiveFormat('pdf')}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'pdf' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>PDF Guide / eBook</span>
          </button>
          <button
            onClick={() => setActiveFormat('social')}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'social' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>10-Part Social Campaign</span>
          </button>
          <button
            onClick={() => setActiveFormat('carousel')}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'carousel' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Carousel Slides</span>
          </button>
          <button
            onClick={() => setActiveFormat('video')}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'video' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Short-Video Script</span>
          </button>
          <button
            onClick={() => setActiveFormat('newsletter')}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'newsletter' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Newsletter Broadcast</span>
          </button>
          <button
            onClick={() => setActiveFormat('pinterest')}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'pinterest' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Pinterest Campaign</span>
          </button>
        </div>

        {/* Content Viewer based on active format */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
          {activeFormat === 'pdf' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Downloadable PDF Guide / Whitepaper</span>
                <button
                  onClick={() => handleCopy('pdf', pdfGuideText)}
                  className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  {copiedKey === 'pdf' ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'pdf' ? 'Copied' : 'Copy Guide Text'}</span>
                </button>
              </div>
              <pre className="text-xs font-mono text-slate-700 bg-white p-3 rounded-lg border border-slate-200 overflow-x-auto whitespace-pre-wrap max-h-72">
                {pdfGuideText}
              </pre>
            </div>
          )}

          {activeFormat === 'social' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Twitter/LinkedIn Thread & Social Posts</span>
                <button
                  onClick={() => handleCopy('social', socialPosts.join('\n\n'))}
                  className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  {copiedKey === 'social' ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'social' ? 'Copied All' : 'Copy All Posts'}</span>
                </button>
              </div>
              <div className="space-y-2">
                {socialPosts.map((post, idx) => (
                  <div key={idx} className="p-2.5 bg-white rounded-lg border border-slate-200 text-xs text-slate-700">
                    {post}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeFormat === 'carousel' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Instagram & LinkedIn 5-Slide Carousel</span>
                <button
                  onClick={() => handleCopy('carousel', JSON.stringify(carouselSlides, null, 2))}
                  className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  {copiedKey === 'carousel' ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'carousel' ? 'Copied' : 'Copy Slides'}</span>
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {carouselSlides.map(slide => (
                  <div key={slide.slide} className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                    <div className="text-[10px] font-mono font-bold text-blue-600 uppercase">Slide {slide.slide}</div>
                    <div className="text-xs font-bold text-slate-900">{slide.title}</div>
                    <div className="text-[11px] text-slate-500">{slide.sub}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeFormat === 'video' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Short Video Script (TikTok, Shorts, Reels)</span>
                <button
                  onClick={() => handleCopy('video', videoScript)}
                  className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  {copiedKey === 'video' ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'video' ? 'Copied' : 'Copy Script'}</span>
                </button>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                {videoScript}
              </div>
            </div>
          )}

          {activeFormat === 'newsletter' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Email Newsletter Broadcast</span>
                <button
                  onClick={() => handleCopy('newsletter', newsletterBroadcast)}
                  className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  {copiedKey === 'newsletter' ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'newsletter' ? 'Copied' : 'Copy Broadcast'}</span>
                </button>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed font-sans">
                {newsletterBroadcast}
              </div>
            </div>
          )}

          {activeFormat === 'pinterest' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Pinterest Title & Description Pack</span>
                <button
                  onClick={() => handleCopy('pinterest', pinterestText)}
                  className="px-3 py-1 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  {copiedKey === 'pinterest' ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'pinterest' ? 'Copied' : 'Copy Pins'}</span>
                </button>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                {pinterestText}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
