import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  Sparkles, 
  Check, 
  Copy, 
  Download, 
  CheckCircle2, 
  Clock, 
  Tag, 
  ExternalLink,
  RefreshCw,
  Edit3,
  ArrowLeft,
  Layers
} from 'lucide-react';
import { BusinessWorkspace, ContentAsset, ContentType, AssetStatus } from '../types/authority';
import { store } from '../services/store';

interface ContentLibraryTabProps {
  workspace: BusinessWorkspace;
  initialAssetSlug?: string;
  onOpenRepurposing?: (asset: ContentAsset) => void;
}

export const ContentLibraryTab: React.FC<ContentLibraryTabProps> = ({
  workspace,
  initialAssetSlug,
  onOpenRepurposing
}) => {
  const assets = workspace.contentAssets;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  const [activeAsset, setActiveAsset] = useState<ContentAsset>(() => {
    if (initialAssetSlug) {
      const found = assets.find(a => a.slug === initialAssetSlug);
      if (found) return found;
    }
    return assets[0];
  });

  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiCustomizationNote, setAiCustomizationNote] = useState('');
  const [copiedMd, setCopiedMd] = useState(false);
  const [mobileView, setMobileView] = useState<'list' | 'reader'>('list');

  // Extract unique categories
  const categories = Array.from(new Set(assets.map(a => a.category)));

  // Filter assets
  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          asset.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          asset.targetKeyword.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || asset.type === selectedType;
    const matchesCat = selectedCategory === 'all' || asset.category === selectedCategory;
    return matchesSearch && matchesType && matchesCat;
  });

  const handleStatusChange = (newStatus: AssetStatus) => {
    const updated = { ...activeAsset, status: newStatus };
    setActiveAsset(updated);
    store.updateContentAsset(workspace.id, updated);
  };

  const handleAiAction = async (actionType: 'customize' | 'expand' | 'rewrite') => {
    setIsAiLoading(true);
    setAiCustomizationNote('');

    try {
      const promptText = actionType === 'customize'
        ? `Brand Voice Customization for "${workspace.brandProfile.name}" (${workspace.nichePackageId}):
Rewrite and optimize this authority article for our audience persona: ${workspace.audienceProfile.targetPersona}.
Current Title: ${activeAsset.title}
Current Excerpt: ${activeAsset.excerpt}
Current Body:
${activeAsset.body}

Inject direct trade tone, practical rules of thumb, and clear transitions linking to related tools.`
        : actionType === 'expand'
        ? `Expand this authority guide with 2 detailed actionable case studies, concrete numbers, and technical execution steps:
Title: ${activeAsset.title}
Body:
${activeAsset.body}`
        : `Rewrite the lead hook and introduction of this article to hook skeptical readers and address common industry objections:
Title: ${activeAsset.title}
Current Excerpt: ${activeAsset.excerpt}`;

      const res = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'customize_content',
          prompt: promptText,
          businessContext: {
            niche: workspace.nichePackageId,
            brandName: workspace.brandProfile.name,
            audience: workspace.audienceProfile.targetPersona
          }
        })
      });

      const data = await res.json();
      if (data.text) {
        const updated = {
          ...activeAsset,
          body: data.text,
          isAiCustomized: true,
          updatedAt: new Date().toISOString().split('T')[0]
        };
        setActiveAsset(updated);
        store.updateContentAsset(workspace.id, updated);
        setAiCustomizationNote(`Successfully updated with ${data.model} AI assistance.`);
      }
    } catch (err: any) {
      setAiCustomizationNote('AI generation failed. Please verify API configuration in Settings > Secrets.');
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleCopyMarkdown = () => {
    const md = `# ${activeAsset.title}\n\n*${activeAsset.excerpt}*\n\n${activeAsset.body}`;
    navigator.clipboard.writeText(md);
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 2000);
  };

  const handleDownloadMarkdown = () => {
    const md = `---
title: "${activeAsset.title}"
slug: "${activeAsset.slug}"
category: "${activeAsset.category}"
reading_time: ${activeAsset.readingTimeMinutes}
target_keyword: "${activeAsset.targetKeyword}"
meta_description: "${activeAsset.metaDescription}"
status: "${activeAsset.status}"
---

# ${activeAsset.title}

*${activeAsset.excerpt}*

${activeAsset.body}`;
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeAsset.slug}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl p-3 sm:p-4 shadow-2xs">
        <div>
          <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>Curated Content Library Engine ({assets.length} Assets)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            40 high-value assets seeded for {workspace.name} · Filter by taxonomy, customize with AI, or export markdown.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onOpenRepurposing && (
            <button
              onClick={() => onOpenRepurposing(activeAsset)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors whitespace-nowrap shadow-2xs"
              title="Transform article into 7 traffic assets (PDF, Social, Video, Carousel, Newsletter, Pinterest)"
            >
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              <span>1-into-7 Repurpose</span>
            </button>
          )}
          <button
            onClick={handleCopyMarkdown}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
          >
            {copiedMd ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedMd ? 'Copied' : 'Copy'}</span>
          </button>
          <button
            onClick={handleDownloadMarkdown}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .MD</span>
          </button>
        </div>
      </div>

      {/* Mobile-Only Segmented View Switcher */}
      <div className="lg:hidden flex items-center p-1 bg-slate-200/70 rounded-xl">
        <button
          onClick={() => setMobileView('list')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors text-center ${
            mobileView === 'list' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
          }`}
        >
          Asset Directory ({filteredAssets.length})
        </button>
        <button
          onClick={() => setMobileView('reader')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors text-center truncate px-2 ${
            mobileView === 'reader' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
          }`}
        >
          Read & Customize
        </button>
      </div>

      {/* Main Grid: Filter List + Reader / AI Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Asset Browser (40 assets) */}
        <div className={`lg:col-span-5 space-y-3 ${
          mobileView === 'reader' ? 'hidden lg:block' : 'block'
        }`}>
          
          {/* Filters Bar */}
          <div className="bg-white border border-slate-200 rounded-xl p-3 space-y-2.5 shadow-2xs">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search 40 curated guides and reviews..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-700"
              >
                <option value="all">All Formats ({assets.length})</option>
                <option value="guide">Guides</option>
                <option value="comparison">Comparisons</option>
                <option value="review">Reviews</option>
                <option value="article">Articles</option>
                <option value="faq">FAQs</option>
                <option value="resource">Resources</option>
              </select>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-700"
              >
                <option value="all">All Categories</option>
                {categories.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Filtered Asset List */}
          <div className="space-y-1.5 max-h-[640px] overflow-y-auto pr-1">
            <div className="text-[11px] font-semibold text-slate-400 px-1 flex items-center justify-between">
              <span>Showing {filteredAssets.length} of {assets.length} assets</span>
              <span className="font-mono text-emerald-600">40 Seeded Total</span>
            </div>

            {filteredAssets.map(asset => {
              const isSelected = asset.id === activeAsset.id;
              return (
                <button
                  key={asset.id}
                  onClick={() => {
                    setActiveAsset(asset);
                    setMobileView('reader');
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                      : 'bg-white border-slate-200 text-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-[10px] font-mono uppercase ${
                      isSelected ? 'text-slate-300' : 'text-slate-500'
                    }`}>
                      {asset.category} · {asset.type}
                    </span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      asset.status === 'approved' 
                        ? isSelected ? 'bg-emerald-950 text-emerald-300' : 'bg-emerald-50 text-emerald-700'
                        : isSelected ? 'bg-slate-800 text-slate-200' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {asset.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold line-clamp-1">
                    {asset.title}
                  </div>
                  <div className={`text-[11px] line-clamp-1 mt-0.5 ${
                    isSelected ? 'text-slate-300' : 'text-slate-500'
                  }`}>
                    {asset.excerpt}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Asset Preview & AI Customization Studio */}
        <div className={`lg:col-span-7 space-y-4 ${
          mobileView === 'list' ? 'hidden lg:block' : 'block'
        }`}>
          {/* Mobile Back Button to return to 40-asset list */}
          <button
            onClick={() => setMobileView('list')}
            className="lg:hidden flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg w-fit transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>&larr; Back to Asset Catalog</span>
          </button>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 shadow-xs space-y-6">
            
            {/* Asset Metadata & Status Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700">{activeAsset.category}</span>
                  <span>·</span>
                  <span className="capitalize">{activeAsset.type}</span>
                  <span>·</span>
                  <span>{activeAsset.readingTimeMinutes} min read</span>
                  {activeAsset.isAiCustomized && (
                    <span className="text-[10px] bg-purple-50 text-purple-700 border border-purple-200 px-1.5 py-0.2 rounded font-semibold flex items-center gap-1">
                      <Sparkles className="w-2.5 h-2.5" /> AI Customized
                    </span>
                  )}
                </div>
                <h2 className="text-lg font-bold text-slate-900 leading-snug">
                  {activeAsset.title}
                </h2>
              </div>

              {/* Status Switcher Buttons */}
              <div className="flex items-center bg-slate-100 p-1 rounded-lg shrink-0 overflow-x-auto max-w-full">
                {(['blueprint', 'draft', 'approved', 'published'] as AssetStatus[]).map(st => (
                  <button
                    key={st}
                    onClick={() => handleStatusChange(st)}
                    className={`px-2.5 py-1 text-[11px] font-semibold rounded capitalize transition-colors ${
                      activeAsset.status === st
                        ? 'bg-white text-slate-900 shadow-2xs font-bold'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* AI Assistant Action Bar */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                  <span>AI Customization Studio (Gemini 3.8 Flash)</span>
                </span>
                {isAiLoading && (
                  <span className="text-[11px] font-mono text-purple-700 animate-pulse flex items-center gap-1">
                    <RefreshCw className="w-3 h-3 animate-spin" /> Customizing...
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                {onOpenRepurposing && (
                  <button
                    onClick={() => onOpenRepurposing(activeAsset)}
                    className="px-3 py-1.5 text-xs font-bold rounded-lg bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-800 transition-colors flex items-center gap-1.5"
                  >
                    <Layers className="w-3.5 h-3.5 text-blue-600" />
                    <span>1-into-7 Repurposing</span>
                  </button>
                )}
                <button
                  onClick={() => handleAiAction('customize')}
                  disabled={isAiLoading}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 transition-colors disabled:opacity-50"
                >
                  Inject Brand Voice & Local Angle
                </button>
                <button
                  onClick={() => handleAiAction('expand')}
                  disabled={isAiLoading}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 transition-colors disabled:opacity-50"
                >
                  Expand With 2 Real Case Studies
                </button>
                <button
                  onClick={() => handleAiAction('rewrite')}
                  disabled={isAiLoading}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 transition-colors disabled:opacity-50"
                >
                  Punch Up Hook & Objections
                </button>
              </div>

              {aiCustomizationNote && (
                <div className="text-[11px] text-slate-600 bg-white p-2 rounded border border-slate-200 mt-2">
                  {aiCustomizationNote}
                </div>
              )}
            </div>

            {/* Excerpt Callout */}
            <div className="bg-slate-50/80 p-3 rounded-lg border-l-2 border-slate-400 text-xs text-slate-600 italic">
              "{activeAsset.excerpt}"
            </div>

            {/* Markdown Body Viewer */}
            <div className="prose prose-slate max-w-none text-xs sm:text-sm text-slate-700 leading-relaxed font-sans space-y-3 whitespace-pre-line border border-slate-100 rounded-xl p-4 bg-slate-50/30">
              {activeAsset.body}
            </div>

            {/* SEO & CTA Bindings Bar */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="font-bold text-slate-700">Target Keyword: </span>
                <span className="font-mono text-slate-600">{activeAsset.targetKeyword}</span>
              </div>
              <div>
                <span className="font-bold text-slate-700">Bound Micro-Tool: </span>
                <span className="text-blue-600 font-semibold">{activeAsset.relatedToolId || 'tool-hi-1'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
