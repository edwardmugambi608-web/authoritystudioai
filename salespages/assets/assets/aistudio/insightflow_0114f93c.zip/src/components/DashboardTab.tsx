import React, { useState, useEffect, useRef } from 'react';
import { 
  RocketLaunch, 
  Sparkle, 
  ArrowRight as PhArrowRight, 
  ArrowsClockwise, 
  GlobeSimple, 
  DownloadSimple, 
  CheckCircle as PhCheckCircle, 
  CaretDown as PhCaretDown,
  CaretUp as PhCaretUp,
  Article, 
  Wrench as PhWrench, 
  EnvelopeSimple, 
  ShareNetwork, 
  CalendarCheck,
  Target as PhTarget,
  ShieldCheck as PhShieldCheck,
  Check as PhCheck,
  Browsers,
  Lightning,
  Coins
} from '@phosphor-icons/react';
import { Loader2 } from 'lucide-react';
import { BusinessWorkspace, ProductTier } from '../types/authority';
import { allNichePackages } from '../data/niches';
import { store, PRODUCT_CONFIGS } from '../services/store';
import { TabKey } from './Sidebar';
import confetti from 'canvas-confetti';

interface DashboardTabProps {
  workspace?: BusinessWorkspace | null;
  currentPlan: ProductTier;
  onNavigateTab: (tab: TabKey) => void;
  onOpenAuditModal: () => void;
  onExportZip: () => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  workspace,
  currentPlan,
  onNavigateTab,
  onOpenAuditModal,
  onExportZip
}) => {
  const [roadmapOpen, setRoadmapOpen] = useState(true);
  const [audienceOpen, setAudienceOpen] = useState(false);
  const [nicheDropdownOpen, setNicheDropdownOpen] = useState(false);
  const nicheDropdownRef = useRef<HTMLDivElement>(null);

  // 2-Click Launcher State
  const [selectedNicheId, setSelectedNicheId] = useState<string>(workspace?.nichePackageId || 'ai-online-business');
  const [businessNameInput, setBusinessNameInput] = useState<string>(workspace?.name || 'NextGen AI Tools');
  const [isBuilding, setIsBuilding] = useState<boolean>(false);
  const [buildStepIndex, setBuildStepIndex] = useState<number>(0);

  const nameSuggestions: Record<string, string[]> = {
    'home-improvement': ['Apex Home Remodeling', 'TrueCraft Renovation Guide', 'BuiltRight Home Hub', 'Precision Remodel Pro'],
    'ai-online-business': ['NextGen AI Tools', 'PromptCraft Studio', 'AutomateScale Hub', 'Vanguard AI Insights'],
    'fitness-wellness': ['Peak Longevity Lab', 'Aegis Performance Protocol', 'VitalPulse Fitness', 'PrimeBio Longevity'],
    'personal-finance': ['Vanguard Wealth Blueprint', 'Compound Freedom Hub', 'Ascend Capital Strategy', 'ProsperWise Guide'],
    'parenting-family': ['Kindred Hearth Family', 'Thriving Roots Parenting', 'NurtureNest Hub', 'ParentCraft Daily']
  };

  const allowedNicheCount = PRODUCT_CONFIGS[currentPlan]?.availableNiches || 5;
  const availableNiches = allNichePackages.slice(0, Math.max(5, allowedNicheCount));
  const selectedPackage = availableNiches.find(p => p.id === selectedNicheId) || availableNiches[0];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (nicheDropdownRef.current && !nicheDropdownRef.current.contains(e.target as Node)) {
        setNicheDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNicheChange = (newNicheId: string) => {
    setSelectedNicheId(newNicheId);
    const list = nameSuggestions[newNicheId] || ['My Authority Business'];
    setBusinessNameInput(list[0]);
  };

  const handleCycleSuggestion = () => {
    const list = nameSuggestions[selectedNicheId] || ['My Authority Business'];
    const currentIdx = list.indexOf(businessNameInput);
    const nextIdx = (currentIdx + 1) % list.length;
    setBusinessNameInput(list[nextIdx]);
  };

  const buildMessages = [
    '⚙️ Initializing brand identity & color tokens...',
    '⚡ Deploying 8 Interactive Micro-Tools with verified formulas...',
    '📄 Binding 40 Authority Articles & Lead Magnet Playbook...',
    '🌐 Structuring 11-Page Authority Website Architecture...'
  ];

  const handleLaunch = () => {
    const finalName = businessNameInput.trim() || 'My Authority Business';
    setIsBuilding(true);
    setBuildStepIndex(0);

    // Multi-step loading sequence over ~3 seconds
    const interval = setInterval(() => {
      setBuildStepIndex((prev) => {
        if (prev < buildMessages.length - 1) {
          return prev + 1;
        }
        return prev;
      });
    }, 750);

    setTimeout(() => {
      clearInterval(interval);
      store.activateInitialNiche(selectedNicheId, finalName, 'hybrid_monetized');
      confetti({ particleCount: 140, spread: 90, origin: { y: 0.5 } });
      setIsBuilding(false);
    }, 3100);
  };

  const activeWs = workspace || store.getActiveWorkspace();

  return (
    <div className="space-y-8 sm:space-y-10 animate-in fade-in duration-150 max-w-full overflow-x-hidden">
      
      {/* Top Launcher Strip (Dropdown + Business Name + Launch Button) - Permanently Expanded */}
      <div className="bg-gradient-to-br from-white via-white to-blue-50/30 border border-slate-200/90 border-t-2 border-t-blue-600 rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-visible space-y-6 z-20">
        
        {/* Header Strip - Permanently Open */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-blue-500/20 shrink-0">
              <RocketLaunch weight="duotone" className="w-5 h-5 text-white" />
            </span>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight font-display">
                {activeWs ? 'Launch New Authority Business' : 'Pick a Niche. Own an Authority Business.'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {activeWs ? 'Deploy an additional turnkey business or switch market targets.' : 'Select a profitable market and name your business below.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-50/90 text-blue-700 border border-blue-200/70 text-xs font-bold font-mono">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
              Turnkey Launcher Active
            </span>
          </div>
        </div>

        {/* The 2-Step Creator Inputs - Permanently Expanded */}
        <div className="pt-4 border-t border-slate-100 space-y-5 animate-in fade-in duration-150">
          {isBuilding ? (
            /* The 3-Second Build Animation */
            <div className="py-10 px-6 text-center space-y-4 bg-slate-50/80 rounded-2xl border border-blue-100">
              <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto" />
              <div className="space-y-1.5">
                <div className="text-sm sm:text-base font-black text-slate-900 font-display">
                  Building Your Authority Business...
                </div>
                <p className="text-xs sm:text-sm font-semibold text-blue-600 font-mono transition-all">
                  {buildMessages[buildStepIndex]}
                </p>
              </div>
              {/* Progress bar */}
              <div className="max-w-md mx-auto h-2.5 bg-slate-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-700 rounded-full"
                  style={{ width: `${((buildStepIndex + 1) / buildMessages.length) * 100}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 sm:gap-6 items-end">
              {/* Step 1: In-App Custom Niche Selector Popover */}
              <div className="md:col-span-5 space-y-2 relative" ref={nicheDropdownRef}>
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700 font-display">
                    Step 1: Select Niche ({allowedNicheCount} Available)
                  </label>
                  <span className="text-[10px] font-medium text-slate-400 font-mono">In-App Selector</span>
                </div>

                {/* Custom Trigger Button */}
                <button
                  type="button"
                  onClick={() => setNicheDropdownOpen(!nicheDropdownOpen)}
                  className="w-full px-4 py-3 text-xs font-semibold rounded-xl border border-slate-300 bg-white text-slate-900 hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all flex items-center justify-between text-left shadow-2xs cursor-pointer min-h-[44px]"
                  aria-haspopup="listbox"
                  aria-expanded={nicheDropdownOpen}
                >
                  <div className="min-w-0 pr-2">
                    <div className="font-bold text-slate-900 truncate">
                      {selectedPackage ? selectedPackage.name : 'Select a Niche'}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono truncate mt-0.5">
                      {selectedPackage?.category || 'Turnkey Niche'} &bull; {selectedPackage?.toolBlueprints?.length || 8} Tools &bull; {selectedPackage?.contentBlueprints?.length || 40} Guides
                    </div>
                  </div>
                  <PhCaretDown weight="bold" className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ${nicheDropdownOpen ? 'rotate-180 text-blue-600' : ''}`} />
                </button>

                {/* In-App Custom Dropdown Menu Popover */}
                {nicheDropdownOpen && (
                  <div className="absolute left-0 top-full mt-2 w-full bg-white border border-slate-200 rounded-2xl shadow-2xl py-2 z-50 max-h-72 overflow-y-auto animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-4 py-2.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                      <span>Available Turnkey Niches ({availableNiches.length})</span>
                      <span className="text-blue-600 font-mono font-bold">In-App</span>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {availableNiches.map(pkg => {
                        const isSelected = pkg.id === selectedNicheId;
                        return (
                          <button
                            key={pkg.id}
                            type="button"
                            onClick={() => {
                              handleNicheChange(pkg.id);
                              setNicheDropdownOpen(false);
                            }}
                            className={`w-full px-4 py-2.5 text-left transition-colors flex items-center justify-between gap-3 cursor-pointer ${
                              isSelected 
                                ? 'bg-blue-50/90 text-blue-950 font-bold' 
                                : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <div className="min-w-0">
                              <div className={`text-xs ${isSelected ? 'font-black text-blue-900' : 'font-bold text-slate-800'}`}>
                                {pkg.name}
                              </div>
                              <div className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
                                {pkg.category} &bull; {pkg.toolBlueprints?.length || 8} Tools &bull; {pkg.contentBlueprints?.length || 40} Guides
                              </div>
                            </div>
                            {isSelected && (
                              <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                                <PhCheck weight="bold" className="w-3 h-3" />
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Step 2: Business Name Input */}
              <div className="md:col-span-4 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700 font-display">
                    Step 2: Business Name
                  </label>
                  <button
                    type="button"
                    onClick={handleCycleSuggestion}
                    className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ArrowsClockwise weight="bold" className="w-3.5 h-3.5" />
                    <span>Suggest</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={businessNameInput}
                  onChange={(e) => setBusinessNameInput(e.target.value)}
                  placeholder="e.g. NextGen AI Tools"
                  className="w-full px-4 py-3 text-xs font-semibold rounded-xl border border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all shadow-2xs min-h-[44px]"
                />
              </div>

              {/* Step 3: Launch Button */}
              <div className="md:col-span-3">
                <button
                  onClick={handleLaunch}
                  disabled={isBuilding}
                  className="w-full py-3 px-4 text-xs font-black rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:via-indigo-500 hover:to-blue-600 text-white shadow-md shadow-indigo-500/20 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer font-display tracking-tight min-h-[44px]"
                >
                  <span>Launch Business</span>
                  <RocketLaunch weight="bold" className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Active Authority Business Status & Action Strip */}
      {activeWs && (
        <div className="bg-gradient-to-br from-white via-white to-blue-50/25 border border-slate-200/90 rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                <span className="font-bold text-blue-600 uppercase tracking-wider">
                  {activeWs.nichePackageId.replace('-', ' ')}
                </span>
                <span>&bull;</span>
                <span className="capitalize">{activeWs.businessModel.replace('_', ' ')}</span>
                <span>&bull;</span>
                <span className="inline-flex items-center gap-1.5 text-emerald-600 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Live & Operational
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight font-display">
                {activeWs.name}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {activeWs.brandProfile.mission || 'Complete authority business ecosystem loaded with 40 articles, 8 interactive micro-tools, and 11 website pages.'}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                onClick={() => onNavigateTab('website')}
                className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200/90 rounded-xl transition-all shadow-2xs hover:-translate-y-0.5 font-display"
              >
                <Browsers weight="duotone" className="w-4 h-4 text-blue-600" />
                <span>Preview 11-Page Website</span>
              </button>
              <button
                onClick={onExportZip}
                className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-slate-950 hover:bg-slate-800 rounded-xl shadow-sm transition-all hover:-translate-y-0.5 font-display"
              >
                <DownloadSimple weight="bold" className="w-4 h-4" />
                <span>Download Business ZIP</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Commercial Asset Valuation & Monetization Readiness (Floating Blue-White Gradient Card) */}
      {activeWs && (
        <div className="bg-gradient-to-br from-white via-blue-50/40 to-indigo-50/25 rounded-3xl p-6 sm:p-8 border border-blue-200/80 shadow-lg shadow-blue-500/8 ring-1 ring-white/90 relative overflow-hidden transition-all hover:shadow-xl hover:shadow-blue-500/10">
          {/* Subtle Ambient Top Accent Glow */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400" />
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-blue-100 gap-4">
            <div>
              <span className="text-[10px] font-mono font-bold text-blue-600 uppercase tracking-wider block">
                Commercial Asset Audit & Valuation
              </span>
              <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight mt-1 font-display">
                Digital Business Valuation & Revenue Readiness
              </h2>
            </div>
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <span className="text-xs font-mono bg-emerald-50 text-emerald-700 border border-emerald-200/80 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 shadow-2xs">
                <PhShieldCheck weight="bold" className="w-4 h-4 text-emerald-600" />
                Turnkey Turn-around Certified
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
            {/* Tile 1: Valuation */}
            <div className="bg-white/90 border border-blue-100/90 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-1.5 hover:border-emerald-300 transition-all hover:shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-500 font-display">Estimated Valuation</span>
                <span className="text-[9px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/60">Audited</span>
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-600 tabular-nums tracking-tight">
                $5,850 – $11,200
              </div>
              <p className="text-[10px] text-slate-500 font-medium">Based on 40 SEO guides, 8 micro-tools & IP assets</p>
            </div>

            {/* Tile 2: Monetization */}
            <div className="bg-white/90 border border-blue-100/90 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-1.5 hover:border-blue-300 transition-all hover:shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-500 font-display">Monetization Readiness</span>
                <span className="text-[9px] font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200/60">Live</span>
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-blue-600 tabular-nums tracking-tight">
                94% Ready
              </div>
              <p className="text-[10px] text-slate-500 font-medium">5 active affiliate hooks & digital checkout wired</p>
            </div>

            {/* Tile 3: Audience Equity */}
            <div className="bg-white/90 border border-blue-100/90 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-1.5 hover:border-amber-300 transition-all hover:shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-500 font-display">Audience Asset Equity</span>
                <span className="text-[9px] font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200/60">Verified</span>
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-amber-600 tabular-nums tracking-tight">
                $1,050+
              </div>
              <p className="text-[10px] text-slate-500 font-medium">420 verified subscribers (@$2.50 industry value)</p>
            </div>

            {/* Tile 4: Footprint */}
            <div className="bg-white/90 border border-blue-100/90 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-1.5 hover:border-indigo-300 transition-all hover:shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-500 font-display">Target Search Footprint</span>
                <span className="text-[9px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200/60">Monthly</span>
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-indigo-600 tabular-nums tracking-tight">
                48,500/mo
              </div>
              <p className="text-[10px] text-slate-500 font-medium">Organic keyword search volume addressed</p>
            </div>
          </div>
        </div>
      )}

      {/* Volume Effect Stats Cards (Full Plan Totals Instead of Single-Niche Counts) */}
      {activeWs && (() => {
        const isUltimate = currentPlan === 'ULTIMATE';
        const isExtendedOrPro = currentPlan === 'EXTENDED' || currentPlan === 'PRO';

        const articlesStat = isUltimate ? '1,800+' : isExtendedOrPro ? '600+' : '200';
        const toolsStat = isUltimate ? '192' : isExtendedOrPro ? '80' : '40';
        const pagesStat = isUltimate ? '264' : isExtendedOrPro ? '110' : '55';
        const leadMagnetStat = isUltimate ? '24' : isExtendedOrPro ? '10' : '5';
        const emailCountStat = isUltimate ? '120' : isExtendedOrPro ? '50' : '25';
        const promoStat = isUltimate ? '480' : isExtendedOrPro ? '200' : '100';
        const nicheCount = isUltimate ? '24' : isExtendedOrPro ? '10' : '5';

        return (
          <div>
            <div className="mb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <div>
                <h2 className="text-sm font-black text-slate-900 tracking-tight">
                  Total Unlocked Business Infrastructure ({nicheCount} Niches Plan)
                </h2>
                <p className="text-xs text-slate-500">
                  Total catalog volume unlocked across your plan edition ({isUltimate ? 'Ultimate 24 Niches' : isExtendedOrPro ? 'Extended 10 Niches' : 'Core 5 Niches'}).
                </p>
              </div>
              <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200/60 self-start sm:self-auto">
                Full Plan Volume
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-5">
              {/* Card 1: Authority Articles & Guides */}
              <div 
                onClick={() => onNavigateTab('content')}
                className="bg-gradient-to-br from-white via-white to-indigo-50/30 border border-slate-200/90 hover:border-indigo-400 rounded-2xl p-5 sm:p-6 shadow-2xs cursor-pointer transition-all hover:shadow-xs group hover:-translate-y-0.5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-500 font-mono text-[11px]">Editorial Library</span>
                  <Article weight="duotone" className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
                </div>
                <div className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tracking-tight tabular-nums">
                  {articlesStat}
                </div>
                <div className="text-xs font-bold text-slate-800 leading-tight font-display">
                  Authority Articles & Guides
                </div>
                <div className="text-[10px] text-emerald-600 font-semibold pt-1 flex items-center gap-1 font-mono">
                  <PhCheckCircle weight="fill" className="w-3.5 h-3.5" /> Full SEO Text Across {nicheCount} Niches
                </div>
              </div>

              {/* Card 2: Interactive Micro-Tools */}
              <div 
                onClick={() => onNavigateTab('tools')}
                className="bg-gradient-to-br from-white via-white to-blue-50/30 border border-slate-200/90 hover:border-blue-400 rounded-2xl p-5 sm:p-6 shadow-2xs cursor-pointer transition-all hover:shadow-xs group hover:-translate-y-0.5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-500 font-mono text-[11px]">Engines</span>
                  <PhWrench weight="duotone" className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                </div>
                <div className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tracking-tight tabular-nums">
                  {toolsStat}
                </div>
                <div className="text-xs font-bold text-slate-800 leading-tight font-display">
                  Interactive Micro-Tools
                </div>
                <div className="text-[10px] text-emerald-600 font-semibold pt-1 flex items-center gap-1 font-mono">
                  <PhCheckCircle weight="fill" className="w-3.5 h-3.5" /> Tested Pure Math
                </div>
              </div>

              {/* Card 3: Website Pages Ready */}
              <div 
                onClick={() => onNavigateTab('website')}
                className="bg-gradient-to-br from-white via-white to-sky-50/30 border border-slate-200/90 hover:border-blue-400 rounded-2xl p-5 sm:p-6 shadow-2xs cursor-pointer transition-all hover:shadow-xs group hover:-translate-y-0.5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-500 font-mono text-[11px]">Portal Architecture</span>
                  <Browsers weight="duotone" className="w-4 h-4 text-slate-400 group-hover:text-sky-600 transition-colors" />
                </div>
                <div className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tracking-tight tabular-nums">
                  {pagesStat}
                </div>
                <div className="text-xs font-bold text-slate-800 leading-tight font-display">
                  Website Pages (11 Per Niche)
                </div>
                <div className="text-[10px] text-blue-600 font-semibold pt-1 flex items-center gap-1 font-mono">
                  <PhCheck weight="bold" className="w-3.5 h-3.5" /> Live Responsive Preview
                </div>
              </div>

              {/* Card 4: Lead Magnet Playbooks & Welcome Emails */}
              <div 
                onClick={() => onNavigateTab('lead_magnet')}
                className="bg-gradient-to-br from-white via-white to-violet-50/30 border border-slate-200/90 hover:border-violet-400 rounded-2xl p-5 sm:p-6 shadow-2xs cursor-pointer transition-all hover:shadow-xs group hover:-translate-y-0.5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-500 font-mono text-[11px]">Funnel Assets</span>
                  <EnvelopeSimple weight="duotone" className="w-4 h-4 text-slate-400 group-hover:text-violet-600 transition-colors" />
                </div>
                <div className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tracking-tight tabular-nums">
                  {leadMagnetStat}
                </div>
                <div className="text-xs font-bold text-slate-800 leading-tight font-display">
                  Lead Magnet Playbooks
                </div>
                <div className="text-[10px] text-emerald-600 font-semibold pt-1 flex items-center gap-1 font-mono">
                  <PhCheckCircle weight="fill" className="w-3.5 h-3.5" /> {emailCountStat} Welcome Emails
                </div>
              </div>

              {/* Card 5: Promotional Campaign Posts */}
              <div 
                onClick={() => onNavigateTab('content')}
                className="bg-gradient-to-br from-white via-white to-emerald-50/30 border border-slate-200/90 hover:border-emerald-400 rounded-2xl p-5 sm:p-6 shadow-2xs cursor-pointer transition-all hover:shadow-xs group col-span-2 sm:col-span-1 hover:-translate-y-0.5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-500 font-mono text-[11px]">Traffic Copy</span>
                  <ShareNetwork weight="duotone" className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                </div>
                <div className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tracking-tight tabular-nums">
                  {promoStat}
                </div>
                <div className="text-xs font-bold text-slate-800 leading-tight font-display">
                  Promotional Posts
                </div>
                <div className="text-[10px] text-blue-600 font-semibold pt-1 flex items-center gap-1 font-mono">
                  <PhCheck weight="bold" className="w-3.5 h-3.5" /> Multi-Platform Campaigns
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Accordion 1: 30-Day Launch Roadmap */}
      {activeWs && (
        <div className="bg-gradient-to-br from-white via-white to-blue-50/20 border border-slate-200/90 rounded-3xl overflow-hidden shadow-sm">
          <button
            onClick={() => setRoadmapOpen(!roadmapOpen)}
            className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-slate-50/70 transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-9 h-9 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold shadow-2xs">
                <CalendarCheck weight="duotone" className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display">30-Day Launch Roadmap</h3>
                <p className="text-xs text-slate-500 mt-0.5">Step-by-step checklist to take this business live and generate traffic</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold font-mono hidden sm:inline">
                {roadmapOpen ? 'Collapse' : 'Expand'}
              </span>
              {roadmapOpen ? <PhCaretUp weight="bold" className="w-4 h-4 text-slate-500" /> : <PhCaretDown weight="bold" className="w-4 h-4 text-slate-500" />}
            </div>
          </button>

          {roadmapOpen && (
            <div className="px-6 pb-6 pt-2 border-t border-slate-100 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-white border border-slate-200/70 space-y-2 shadow-2xs">
                  <div className="text-[10px] font-mono font-bold text-blue-600 uppercase">Week 1: Setup</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 font-display">Brand & Foundation</div>
                  <p className="text-xs text-slate-600 leading-relaxed">Review business name, tagline, and test your 8 interactive micro-tools.</p>
                  <div className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 font-mono pt-1">
                    <PhCheckCircle weight="fill" className="w-3.5 h-3.5" /> Complete
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200/70 space-y-2 shadow-2xs">
                  <div className="text-[10px] font-mono font-bold text-blue-600 uppercase">Week 2: Content</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 font-display">Publish Authority Articles</div>
                  <p className="text-xs text-slate-600 leading-relaxed">Select 5 top guides and link them directly to your micro-tools.</p>
                  <div className="text-[10px] text-blue-600 font-semibold flex items-center gap-1 font-mono pt-1">
                    &bull; In Progress
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200/70 space-y-2 shadow-2xs">
                  <div className="text-[10px] font-mono font-bold text-slate-400 uppercase">Week 3: Leads</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 font-display">Lead Magnet & Emails</div>
                  <p className="text-xs text-slate-600 leading-relaxed">Connect your autoresponder and verify your 5-day welcome sequence.</p>
                  <div className="text-[10px] text-slate-400 font-semibold font-mono pt-1">
                    &bull; Next Step
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200/70 space-y-2 shadow-2xs">
                  <div className="text-[10px] font-mono font-bold text-slate-400 uppercase">Week 4: Launch</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 font-display">Monetize & Traffic</div>
                  <p className="text-xs text-slate-600 leading-relaxed">Add affiliate links, digital checkout, and share your starter promo posts.</p>
                  <div className="text-[10px] text-slate-400 font-semibold font-mono pt-1">
                    &bull; Final Milestone
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => onNavigateTab('launch_plan')}
                  className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 font-display hover:underline"
                >
                  <span>View Full 30-Day Calendar</span>
                  <PhArrowRight weight="bold" className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Accordion 2: Target Audience & Strategy */}
      {activeWs && (
        <div className="bg-gradient-to-br from-white via-white to-blue-50/20 border border-slate-200/90 rounded-3xl overflow-hidden shadow-sm">
          <button
            onClick={() => setAudienceOpen(!audienceOpen)}
            className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-slate-50/70 transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold shadow-2xs">
                <PhTarget weight="duotone" className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 font-display">Target Audience & Market Strategy</h3>
                <p className="text-xs text-slate-500 mt-0.5">Who your authority business is built for and what problems it solves</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold font-mono hidden sm:inline">
                {audienceOpen ? 'Collapse' : 'Expand'}
              </span>
              {audienceOpen ? <PhCaretUp weight="bold" className="w-4 h-4 text-slate-500" /> : <PhCaretDown weight="bold" className="w-4 h-4 text-slate-500" />}
            </div>
          </button>

          {audienceOpen && (
            <div className="px-6 pb-6 pt-2 border-t border-slate-100 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">Primary Reader Persona</span>
                  <p className="text-xs sm:text-sm font-semibold text-slate-800">{activeWs.audienceProfile.targetPersona}</p>
                  <p className="text-xs text-slate-600 leading-relaxed">{activeWs.audienceProfile.toneAndVoice}</p>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">Core Frustrations Solved</span>
                  <ul className="text-xs text-slate-600 space-y-1.5">
                    {(activeWs.audienceProfile.corePainPoints || []).slice(0, 3).map((pt: string, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-rose-500 font-bold">&times;</span>
                        <span className="leading-relaxed">{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">Primary Desires</span>
                  <ul className="text-xs text-slate-600 space-y-1.5">
                    {activeWs.audienceProfile.primaryDesires.slice(0, 3).map((ds, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-emerald-500 font-bold">&bull;</span>
                        <span className="leading-relaxed">{ds}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
