import React, { useState } from 'react';
import { 
  ShieldAlert, 
  ExternalLink, 
  Copy, 
  Check, 
  Sparkles, 
  Key, 
  Radio, 
  Layers, 
  Building2, 
  Cloud, 
  MapPin, 
  Calendar, 
  RefreshCw, 
  Sliders, 
  ShieldCheck, 
  Edit2, 
  Save, 
  X,
  Zap,
  Globe
} from 'lucide-react';
import { store, PRODUCT_CONFIGS } from '../services/store';
import { ProductTier } from '../types/authority';
import confetti from 'canvas-confetti';

interface AdminTabProps {
  onOpenAuditModal: () => void;
  onSelectSuite: (suite: ProductTier) => void;
}

interface FunnelItem {
  tier: ProductTier;
  label: string;
  badge: string;
  price: string;
  secretKey: string;
  defaultSalesUrl: string;
  icon: React.ElementType;
}

export const AdminTab: React.FC<AdminTabProps> = ({
  onOpenAuditModal,
  onSelectSuite
}) => {
  const currentPlan = store.getPlan();
  const currentUser = store.getCurrentUser();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [copiedDeliveryUrl, setCopiedDeliveryUrl] = useState<string | null>(null);
  const [editingTier, setEditingTier] = useState<ProductTier | null>(null);
  const [editUrlInput, setEditUrlInput] = useState('');

  const funnelItems: FunnelItem[] = [
    {
      tier: 'CORE',
      label: 'Authority Studio AI (Front End)',
      badge: 'FE • 5 Niches',
      price: '$27',
      secretKey: PRODUCT_CONFIGS.CORE.secretDeliveryKey || 'auth_core_access_secret',
      defaultSalesUrl: 'https://authority-studio.web.app/core',
      icon: Zap
    },
    {
      tier: 'EXTENDED',
      label: 'Authority Studio AI Extended (OTO 1)',
      badge: 'OTO 1 • 10 Niches',
      price: '$47',
      secretKey: PRODUCT_CONFIGS.EXTENDED.secretDeliveryKey || 'auth_ext_secret_access',
      defaultSalesUrl: 'https://authority-studio.web.app/extended',
      icon: Radio
    },
    {
      tier: 'PRO',
      label: 'Authority Studio AI Pro (OTO 2)',
      badge: 'OTO 2 • 10 Niches',
      price: '$67',
      secretKey: PRODUCT_CONFIGS.PRO.secretDeliveryKey || 'auth_pro_secret_access',
      defaultSalesUrl: 'https://authority-studio.web.app/pro',
      icon: Layers
    },
    {
      tier: 'ULTIMATE',
      label: 'Authority Studio AI Ultimate (OTO 3)',
      badge: 'OTO 3 • 24 Niches',
      price: '$97',
      secretKey: PRODUCT_CONFIGS.ULTIMATE.secretDeliveryKey || 'auth_ult_secret_access',
      defaultSalesUrl: 'https://authority-studio.web.app/ultimate',
      icon: Building2
    }
  ];

  const getOrigin = () => {
    if (typeof window !== 'undefined') {
      return window.location.origin;
    }
    return 'https://authority-studio.web.app';
  };

  const getDeliveryUrl = (key: string) => {
    return `${getOrigin()}/?delivery=${encodeURIComponent(key)}`;
  };

  const copyToClipboard = (text: string, type: 'key' | 'url', id: string) => {
    navigator.clipboard.writeText(text);
    if (type === 'key') {
      setCopiedKey(id);
      setTimeout(() => setCopiedKey(null), 2000);
    } else {
      setCopiedDeliveryUrl(id);
      setTimeout(() => setCopiedDeliveryUrl(null), 2000);
    }
  };

  const handleStartEdit = (item: FunnelItem) => {
    setEditingTier(item.tier);
    setEditUrlInput(store.getSalesUrl(item.tier) || item.defaultSalesUrl);
  };

  const handleSaveEdit = (tier: ProductTier) => {
    if (editUrlInput.trim()) {
      store.setSalesUrl(tier, editUrlInput.trim());
    }
    setEditingTier(null);
  };

  const handleTestDelivery = (key: string) => {
    const res = store.unlockBySecretKey(key);
    if (res.success) {
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-in fade-in duration-150 pb-12">
      
      {/* Top Banner: Admin Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono text-xs font-bold tracking-wide">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Exclusive Founder & Admin Hub</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              WarriorPlus Funnel & Delivery Control
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Manage WarriorPlus instant delivery links, verify buyer secret keys, configure dedicated sales pages, test plan unlocks, and launch deep catalog audits.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => {
                store.adminUnlockAllTiers();
                onSelectSuite('ULTIMATE');
                confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-emerald-200" />
              <span>Unlock All OTOs</span>
            </button>

            <button
              onClick={() => {
                store.adminResetToCore();
                onSelectSuite('CORE');
              }}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all flex items-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
              <span>Reset to Core Only</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin Plan Quick Switcher & Testing Strip */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-600" />
              <span>Live Plan Simulator & Switcher</span>
            </h2>
            <p className="text-xs text-slate-500">
              Instantly toggle the active plan tier to inspect what each customer tier sees:
            </p>
          </div>
          <div className="text-xs font-mono font-bold text-slate-500">
            Active: <span className="text-blue-600 uppercase font-black">{currentPlan}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {funnelItems.map(item => {
            const isActive = currentPlan === item.tier;
            const isUnlocked = store.hasAccessToTier(item.tier);
            const Icon = item.icon;

            return (
              <button
                key={item.tier}
                onClick={() => {
                  store.setPlan(item.tier);
                  if (item.tier === 'CORE' || item.tier === 'EXTENDED' || item.tier === 'PRO' || item.tier === 'ULTIMATE') {
                    onSelectSuite(item.tier);
                  }
                }}
                className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all ${
                  isActive
                    ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500/20 text-blue-900'
                    : isUnlocked
                    ? 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-800'
                    : 'bg-white border-dashed border-slate-200 hover:border-slate-300 text-slate-500'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                  {isActive && <Check className="w-3.5 h-3.5 text-blue-600" />}
                </div>
                <div className="text-xs font-bold truncate w-full">{item.tier}</div>
                <div className="text-[10px] text-slate-500">{item.price}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* WarriorPlus Delivery Matrix Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Key className="w-4 h-4 text-emerald-600" />
              <span>WarriorPlus Products & Direct Delivery URLs</span>
            </h2>
            <p className="text-xs text-slate-500">
              Copy these URLs directly into your WarriorPlus Product Setup &gt; Direct Delivery / Access URL field.
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {funnelItems.map(item => {
            const Icon = item.icon;
            const salesUrl = store.getSalesUrl(item.tier) || item.defaultSalesUrl;
            const deliveryUrl = getDeliveryUrl(item.secretKey);
            const isEditing = editingTier === item.tier;
            const isKeyCopied = copiedKey === item.tier;
            const isUrlCopied = copiedDeliveryUrl === item.tier;

            return (
              <div key={item.tier} className="p-5 hover:bg-slate-50/50 transition-colors space-y-4">
                
                {/* Product Title Strip */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="w-9 h-9 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center font-bold">
                      <Icon className="w-4 h-4 text-slate-700" />
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{item.label}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold border border-blue-200/60">
                          {item.badge}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        Launch Price: <strong className="text-slate-800">{item.price}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleTestDelivery(item.secretKey)}
                      className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
                      title="Test secret delivery flow"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-500" />
                      <span>Test Delivery</span>
                    </button>
                  </div>
                </div>

                {/* Grid: Sales Page URL + Direct Delivery URL + Secret Key */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 pt-1">
                  
                  {/* Column 1: Dedicated Sales Page (.web.app) */}
                  <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                      <span className="flex items-center gap-1">
                        <Globe className="w-3 h-3 text-slate-500" />
                        <span>Dedicated Sales Page</span>
                      </span>
                      {!isEditing ? (
                        <button
                          onClick={() => handleStartEdit(item)}
                          className="text-[10px] text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
                        >
                          <Edit2 className="w-2.5 h-2.5" /> Edit
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleSaveEdit(item.tier)}
                            className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5"
                          >
                            <Save className="w-2.5 h-2.5" /> Save
                          </button>
                          <button
                            onClick={() => setEditingTier(null)}
                            className="text-[10px] text-slate-400 hover:text-slate-600"
                          >
                            <X className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      )}
                    </div>

                    {isEditing ? (
                      <input
                        type="url"
                        value={editUrlInput}
                        onChange={e => setEditUrlInput(e.target.value)}
                        className="w-full px-2 py-1 text-xs border border-blue-400 rounded bg-white text-slate-900 font-mono"
                        autoFocus
                      />
                    ) : (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-mono text-slate-600 truncate">
                          {salesUrl}
                        </span>
                        <a
                          href={salesUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1 text-slate-400 hover:text-blue-600 transition-colors shrink-0"
                          title="Open sales page"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Column 2: WarriorPlus Direct Delivery Link */}
                  <div className="p-3 bg-emerald-50/60 border border-emerald-200/80 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-bold text-emerald-900">
                      <span>WarriorPlus Access / Delivery URL</span>
                      <button
                        onClick={() => copyToClipboard(deliveryUrl, 'url', item.tier)}
                        className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1"
                      >
                        {isUrlCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        <span>{isUrlCopied ? 'Copied!' : 'Copy URL'}</span>
                      </button>
                    </div>
                    <div className="text-[11px] font-mono text-emerald-800 bg-white/70 px-2 py-1 rounded border border-emerald-200 truncate select-all">
                      {deliveryUrl}
                    </div>
                  </div>

                  {/* Column 3: Secret Delivery Key */}
                  <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                      <span>Secret Delivery Key</span>
                      <button
                        onClick={() => copyToClipboard(item.secretKey, 'key', item.tier)}
                        className="text-[10px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1"
                      >
                        {isKeyCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        <span>{isKeyCopied ? 'Copied!' : 'Copy Key'}</span>
                      </button>
                    </div>
                    <div className="text-[11px] font-mono text-slate-800 bg-white px-2 py-1 rounded border border-slate-200 truncate select-all font-semibold">
                      {item.secretKey}
                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Technical Catalog Verification Audit Section */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h3 className="text-sm sm:text-base font-black text-slate-900">
              Technical Catalog Verification & Verification Suite
            </h3>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Verify the mathematical integrity, article counts, formula deterministic execution, and deliverable numbers across all 24 niches (1,800+ assets, 192 interactive tools, 264 pages).
          </p>
        </div>

        <button
          onClick={onOpenAuditModal}
          className="px-5 py-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 shrink-0"
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Launch Full Catalog Audit</span>
        </button>
      </div>

    </div>
  );
};
