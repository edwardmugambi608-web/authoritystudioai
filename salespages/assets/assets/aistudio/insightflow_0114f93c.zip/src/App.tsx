import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar, TabKey } from './components/Sidebar';
import { DashboardTab } from './components/DashboardTab';
import { LaunchPlanTab } from './components/LaunchPlanTab';
import { WebsitePreviewTab } from './components/WebsitePreviewTab';
import { MicroToolsTab } from './components/MicroToolsTab';
import { ContentLibraryTab } from './components/ContentLibraryTab';
import { LeadMagnetTab } from './components/LeadMagnetTab';
import { MonetizationTab } from './components/MonetizationTab';
import { ExportsTab } from './components/ExportsTab';
import { OperationsTab } from './components/OperationsTab';
import { PortfolioTab } from './components/PortfolioTab';
import { CommercialTab } from './components/CommercialTab';
import { CatalogAuditModal } from './components/CatalogAuditModal';
import { CreateBusinessModal } from './components/CreateBusinessModal';
import { AuthModal } from './components/AuthModal';
import { UpgradeWallModal } from './components/UpgradeWallModal';
import { NicheSelectionHub } from './components/NicheSelectionHub';
import { SecretDeliveryModal } from './components/SecretDeliveryModal';
import { NicheVaultModal } from './components/NicheVaultModal';
import { LoginPage } from './components/LoginPage';
import { AdminTab } from './components/AdminTab';
import { RepurposingModal } from './components/RepurposingModal';
import { store, PRODUCT_CONFIGS } from './services/store';
import { ProductTier, BusinessWorkspace, ContentAsset } from './types/authority';
import { generateBusinessInABoxZip } from './services/export-service';
import { LayoutDashboard, Compass, Wrench, FileText, Menu as MenuIcon } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  const [, setTick] = useState(0);

  // Subscribe to reactive store
  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      setTick(t => t + 1);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const activeWorkspace = store.getActiveWorkspace();
  const currentPlan = store.getPlan();
  const hasChosenInitialNiche = store.getHasChosenInitialNiche();

  // Active Product Suite State (CORE | EXTENDED | PRO | ULTIMATE)
  const [activeSuite, setActiveSuite] = useState<ProductTier>('CORE');

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<TabKey>('dashboard');

  // Deep linking selections
  const [selectedToolSlug, setSelectedToolSlug] = useState<string | undefined>();
  const [selectedAssetSlug, setSelectedAssetSlug] = useState<string | undefined>();

  // OTO Launcher deep links & modals
  const [repurposingModalOpen, setRepurposingModalOpen] = useState(false);
  const [repurposingAsset, setRepurposingAsset] = useState<ContentAsset | null>(null);
  const [portfolioOpenClone, setPortfolioOpenClone] = useState(false);
  const [commercialSubSection, setCommercialSubSection] = useState<'clients' | 'license' | 'local_package' | 'event_package'>('clients');

  // Modals & Navigation state
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [auditModalOpen, setAuditModalOpen] = useState(false);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [nicheHubOpen, setNicheHubOpen] = useState(false);
  const [vaultModalOpen, setVaultModalOpen] = useState(false);
  const [upgradeWallOpen, setUpgradeWallOpen] = useState(false);
  const [upgradeWallTargetTier, setUpgradeWallTargetTier] = useState<ProductTier>('EXTENDED');
  const [upgradeWallFeature, setUpgradeWallFeature] = useState<string | undefined>();

  // Secret Delivery Modal state
  const [deliveredTier, setDeliveredTier] = useState<ProductTier | null>(null);

  // Detect secret delivery URLs on page load (e.g. ?delivery=auth_ext_secret_access or /delivery/...)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const searchParams = new URLSearchParams(window.location.search);
    const deliveryParam = searchParams.get('delivery');
    const path = window.location.pathname.toLowerCase();

    let keyToRedeem: string | null = null;

    if (deliveryParam) {
      keyToRedeem = deliveryParam;
    } else if (path.includes('/delivery/extended') || path.includes('/extended')) {
      keyToRedeem = 'auth_ext_secret_access';
    } else if (path.includes('/delivery/pro') || path.includes('/pro')) {
      keyToRedeem = 'auth_pro_secret_access';
    } else if (path.includes('/delivery/ultimate') || path.includes('/ultimate')) {
      keyToRedeem = 'auth_ult_secret_access';
    } else if (path.includes('/delivery/cloud') || path.includes('/cloud')) {
      keyToRedeem = 'auth_cloud_secret_access';
    } else if (path.includes('/delivery/local') || path.includes('/local')) {
      keyToRedeem = 'auth_local_secret_access';
    } else if (path.includes('/delivery/event') || path.includes('/event')) {
      keyToRedeem = 'auth_event_secret_access';
    }

    if (keyToRedeem) {
      const res = store.unlockBySecretKey(keyToRedeem);
      if (res.success && res.tier) {
        setDeliveredTier(res.tier);
        confetti({ particleCount: 150, spread: 90, origin: { y: 0.5 } });
      }
    }
  }, []);

  // Quick ZIP export from header
  const handleQuickExportZip = async () => {
    if (!activeWorkspace) return;
    try {
      const blob = await generateBusinessInABoxZip(activeWorkspace);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeWorkspace.brandProfile.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-business-in-a-box.zip`;
      a.click();
      URL.revokeObjectURL(url);
      confetti({ particleCount: 75, spread: 65, origin: { y: 0.6 } });
    } catch (e) {
      console.error(e);
    }
  };

  const handleNavigateToTool = (slug: string) => {
    setSelectedToolSlug(slug);
    setActiveTab('tools');
    setMobileMenuOpen(false);
  };

  const handleNavigateToContent = (slug: string) => {
    setSelectedAssetSlug(slug);
    setActiveTab('content');
    setMobileMenuOpen(false);
  };

  const handleOpenUpgradeWall = (tier?: ProductTier, featureName?: string) => {
    setUpgradeWallTargetTier(tier || store.getNextUpgradeTier() || 'EXTENDED');
    setUpgradeWallFeature(featureName);
    setUpgradeWallOpen(true);
  };

  const handleSelectTab = (tab: TabKey) => {
    setMobileMenuOpen(false);
    if (tab === 'catalog_audit') {
      setAuditModalOpen(true);
      return;
    }
    if (tab === 'repurposing') {
      if (activeWorkspace && activeWorkspace.contentAssets && activeWorkspace.contentAssets.length > 0) {
        setRepurposingAsset(activeWorkspace.contentAssets[0]);
      }
      setRepurposingModalOpen(true);
      return;
    }
    if (tab === 'cloner') {
      setPortfolioOpenClone(true);
      setActiveTab('portfolio');
      return;
    }
    if (tab === 'client_portals') {
      setCommercialSubSection('clients');
      setActiveTab('commercial');
      return;
    }
    if (tab === 'license') {
      setCommercialSubSection('license');
      setActiveTab('commercial');
      return;
    }
    if (tab === 'local_event') {
      setCommercialSubSection('local_package');
      setActiveTab('commercial');
      return;
    }
    if (tab !== 'portfolio') {
      setPortfolioOpenClone(false);
    }
    setActiveTab(tab);
  };

  const currentUser = store.getCurrentUser();

  if (!currentUser) {
    return <LoginPage onLoginSuccess={() => setTick(t => t + 1)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fbff] via-white to-[#edf5ff] bg-ambient-light flex flex-col font-sans text-slate-900 antialiased selection:bg-blue-100 selection:text-blue-900 overflow-x-hidden w-full max-w-full">
      
      {/* 3-Zone Top Bar */}
      <Header
        activeWorkspace={activeWorkspace}
        currentPlan={currentPlan}
        activeSuite={activeSuite}
        onSelectSuite={(suite) => setActiveSuite(suite)}
        onOpenCreateModal={() => setCreateModalOpen(true)}
        onOpenUpgradeWall={(tier, feature) => handleOpenUpgradeWall(tier, feature)}
        onOpenAuditModal={() => setAuditModalOpen(true)}
        onOpenAuthModal={() => setAuthModalOpen(true)}
        onOpenNicheHub={() => handleSelectTab('niches')}
        onOpenVaultModal={() => setVaultModalOpen(true)}
        onQuickExportZip={handleQuickExportZip}
        onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
        isMobileMenuOpen={mobileMenuOpen}
        onNavigateTab={(tab) => handleSelectTab(tab as TabKey)}
      />

      {/* Main Body with Docked Left Sidebar on Desktop & Dynamic Content Canvas */}
      <div className="flex-1 flex w-full relative min-w-0">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={handleSelectTab}
          currentPlan={currentPlan}
          activeSuite={activeSuite}
          onSelectSuite={(suite) => {
            setActiveSuite(suite);
            store.setPlan(suite);
          }}
          onUpgradePrompt={(feat, tier) => handleOpenUpgradeWall(tier, feat)}
          onOpenVaultModal={() => setVaultModalOpen(true)}
          isOpen={mobileMenuOpen}
          onClose={() => setMobileMenuOpen(false)}
          onOpenCreateModal={() => {
            setMobileMenuOpen(false);
            setCreateModalOpen(true);
          }}
        />

        {/* Main Content Canvas */}
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 min-w-0 overflow-x-hidden pb-12">
        {activeTab === 'admin' && (
          <AdminTab
            onOpenAuditModal={() => setAuditModalOpen(true)}
            onSelectSuite={setActiveSuite}
          />
        )}

        {activeTab === 'niches' && (
          <NicheSelectionHub
            onNicheActivated={() => {
              setActiveTab('dashboard');
            }}
            onOpenUpgradeWall={(tier, feat) => handleOpenUpgradeWall(tier, feat)}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardTab
            workspace={activeWorkspace}
            currentPlan={currentPlan}
            onNavigateTab={handleSelectTab}
            onOpenAuditModal={() => setAuditModalOpen(true)}
            onExportZip={handleQuickExportZip}
          />
        )}

        {activeTab !== 'niches' && activeTab !== 'dashboard' && activeTab !== 'admin' && activeWorkspace && (
          <>

              {activeTab === 'launch_plan' && (
                <LaunchPlanTab
                  workspace={activeWorkspace}
                  onNavigateTab={handleSelectTab}
                />
              )}

              {activeTab === 'website' && (
                <WebsitePreviewTab
                  workspace={activeWorkspace}
                  onNavigateToTool={handleNavigateToTool}
                  onNavigateToContent={handleNavigateToContent}
                />
              )}

              {activeTab === 'tools' && (
                <MicroToolsTab
                  workspace={activeWorkspace}
                  initialToolSlug={selectedToolSlug}
                />
              )}

              {activeTab === 'content' && (
                <ContentLibraryTab
                  workspace={activeWorkspace}
                  initialAssetSlug={selectedAssetSlug}
                  onOpenRepurposing={(asset) => {
                    setRepurposingAsset(asset);
                    setRepurposingModalOpen(true);
                  }}
                />
              )}

              {activeTab === 'lead_magnet' && (
                <LeadMagnetTab
                  workspace={activeWorkspace}
                />
              )}

              {activeTab === 'monetization' && (
                <MonetizationTab
                  workspace={activeWorkspace}
                />
              )}

              {activeTab === 'exports' && (
                <ExportsTab
                  workspace={activeWorkspace}
                />
              )}

              {activeTab === 'operations' && (
                <OperationsTab
                  workspace={activeWorkspace}
                  currentPlan={currentPlan}
                />
              )}

              {activeTab === 'portfolio' && (
                <PortfolioTab
                  currentPlan={currentPlan}
                  initialOpenClone={portfolioOpenClone}
                  onOpenCreateModal={() => setCreateModalOpen(true)}
                  onSelectWorkspace={() => {
                    setPortfolioOpenClone(false);
                    setActiveTab('dashboard');
                  }}
                />
              )}

              {activeTab === 'commercial' && (
                <CommercialTab
                  currentPlan={currentPlan}
                  activeWorkspace={activeWorkspace}
                  initialSubSection={commercialSubSection}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Frictionless User Authentication Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />

      {/* Commercial Upgrade Wall Modal (Links to Firebase web.app + Instant Secret Key simulation) */}
      <UpgradeWallModal
        isOpen={upgradeWallOpen}
        onClose={() => setUpgradeWallOpen(false)}
        targetTier={upgradeWallTargetTier}
        featureName={upgradeWallFeature}
      />

      {/* Secret Product Delivery Modal */}
      {deliveredTier && (
        <SecretDeliveryModal
          isOpen={!!deliveredTier}
          onClose={() => setDeliveredTier(null)}
          unlockedTier={deliveredTier}
          onNavigateToTab={(t) => setActiveTab(t as TabKey)}
          onOpenUpgradeWall={(tier, feat) => handleOpenUpgradeWall(tier, feat)}
        />
      )}

      {/* Niche Launch Vault Bump Modal */}
      <NicheVaultModal
        isOpen={vaultModalOpen}
        onClose={() => setVaultModalOpen(false)}
      />

      {/* Automated Catalog Verification Modal */}
      <CatalogAuditModal
        isOpen={auditModalOpen}
        onClose={() => setAuditModalOpen(false)}
      />

      {/* Step-by-Step Business Setup Wizard Modal */}
      <CreateBusinessModal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        onBusinessCreated={(newWsId) => {
          store.setActiveWorkspace(newWsId);
          setActiveTab('dashboard');
        }}
      />

      {/* 1-into-7 Traffic Repurposing Engine Modal */}
      {activeWorkspace && activeWorkspace.contentAssets && activeWorkspace.contentAssets.length > 0 && (
        <RepurposingModal
          isOpen={repurposingModalOpen}
          onClose={() => setRepurposingModalOpen(false)}
          workspace={activeWorkspace}
          asset={repurposingAsset || activeWorkspace.contentAssets[0]}
          onOpenUpgradeWall={(tier, feat) => handleOpenUpgradeWall(tier, feat)}
        />
      )}

    </div>
  );
}
